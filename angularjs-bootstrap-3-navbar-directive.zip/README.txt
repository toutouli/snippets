A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/GJMraG.

 A navbar directive to recreate the Bootstrap navbar by feeding the directive attributes rather than having to recreate the Bootstrap navbar example every time when writing a new application.  Two way binding between the navbar's menu items and the controller allows for dynamic creation and editting of the navbar's menus.

Forked from [Michael E Conroy](http://codepen.io/m-e-conroy/)'s Pen [AngularJS / Bootstrap 3 Navbar Directive](http://codepen.io/m-e-conroy/pen/bcEsA/).